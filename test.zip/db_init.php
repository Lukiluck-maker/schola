<?php
// db_init.php — uruchom raz, potem możesz usunąć lub zmienić nazwę
try {
    $dbFile = __DIR__ . '/db.sqlite';
    $db = new PDO('sqlite:' . $dbFile);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = <<<SQL
CREATE TABLE IF NOT EXISTS songs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  hymn_number TEXT,
  period TEXT,
  type TEXT,
  status TEXT,
  notes TEXT,
  audio TEXT,
  pdf TEXT,
  lyrics TEXT,
  created_at DATETIME DEFAULT (datetime('now'))
);
SQL;

    $db->exec($sql);
    echo "OK — baza utworzona: " . basename($dbFile);
} catch (Exception $e) {
    echo "Błąd: " . htmlspecialchars($e->getMessage());
}