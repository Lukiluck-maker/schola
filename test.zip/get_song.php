<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

$servername = "localhost";    // adres serwera bazy danych (zwykle localhost)
$username = "twoj_user";      // Twój login do bazy
$password = "twoje_haslo";    // Twoje hasło do bazy
$dbname = "twoja_baza";       // nazwa bazy danych

$conn = new mysqli('localhost', 'root', '','schola');

if ($conn->connect_error) {
    echo json_encode(['error' => 'Błąd połączenia z bazą danych']);
    exit;
}

if (!isset($_GET['id'])) {
    echo json_encode(['error' => 'Brak ID pieśni']);
    exit;
}

$id = intval($_GET['id']); // zabezpieczenie na wypadek złego ID

$sql = "SELECT * FROM piesni WHERE id = $id";  // dopasuj nazwę tabeli i kolumn, jeśli masz inne
$result = $conn->query($sql);

if ($result->num_rows === 0) {
    echo json_encode(['error' => 'Nie znaleziono pieśni']);
    exit;
}

$song = $result->fetch_assoc();

echo json_encode($song);

$conn->close();
?>