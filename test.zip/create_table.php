<?php
try {
    $db = new PDO('sqlite:' . __DIR__ . '/db.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "CREATE TABLE IF NOT EXISTS piesni (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        tytul TEXT NOT NULL,
        hymn_number TEXT,
        okres TEXT,
        rodzaj TEXT,
        status TEXT,
        notes TEXT,
        audio TEXT,
        tekst TEXT
    )";

    $db->exec($sql);

    echo "Tabela 'piesni' została utworzona (lub już istniała).";
} catch (Exception $e) {
    echo "Błąd: " . $e->getMessage();
}
?>
