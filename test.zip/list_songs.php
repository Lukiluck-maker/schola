<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$conn = new mysqli('localhost', 'root', '', 'schola');
if ($conn->connect_error) {
  die("Błąd połączenia z bazą: " . $conn->connect_error);
}

$sql = "SELECT tytul, okres, rodzaj, status FROM piesni ORDER BY tytul ASC";
$result = $conn->query($sql);

if (!$result) {
    die("Błąd zapytania: " . $conn->error);
}

if ($result->num_rows > 0):
    // tutaj wyświetlasz listę
else:
    echo "<p>Brak pieśni w bazie.</p>";
endif;

?>

<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <title>Lista pieśni scholi</title>
</head>
<body>
  <h1>Lista pieśni</h1>

  <?php if ($result->num_rows > 0): ?>
    <ul>
    <?php while($row = $result->fetch_assoc()): ?>
      <li>
        <?= htmlspecialchars($row['tytul']) ?> — <?= htmlspecialchars($row['okres']) ?>, <?= htmlspecialchars($row['rodzaj']) ?>, status: <?= htmlspecialchars($row['status']) ?>
      </li>
    <?php endwhile; ?>
    </ul>
  <?php else: ?>
    <p>Brak pieśni w bazie.</p>
  <?php endif; ?>

</body>
</html>

<?php $conn->close(); ?>