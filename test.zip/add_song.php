<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// add_song.php
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        header('Location: add_song_form.html');
        exit;
    }

    $db = new PDO('sqlite:' . __DIR__ . '/db.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $tytul = trim($_POST['tytul'] ?? '');
    if ($tytul === '') throw new Exception('Brak tytułu');

    $stmt = $db->prepare("INSERT INTO piesni (tytul, hymn_number, okres, rodzaj, status, notes, audio, pdf, tekst) VALUES (:tytul,:hymn_number,:okres,:rodzaj,:status,:notes,:audio,:pdf,:tekst)");
    $stmt->execute([
        ':tytul' => $tytul,
        ':hymn_number' => $_POST['hymn_number'] ?? null,
        ':okres' => $_POST['okres'] ?? null,
        ':rodzaj' => $_POST['rodzaj'] ?? null,
        ':status' => $_POST['status'] ?? null,
        ':notatki' => $_POST['notatki'] ?? null,
        ':audio' => $_POST['audio'] ?? null,
        ':pdf' => $_POST['pdf'] ?? null,
        ':tekst' => $_POST['tekst'] ?? null,
    ]);

    // prosty redirect po dodaniu
    header('Location: add_song_form.html?ok=1');
    exit;
} catch (Exception $e) {
    echo "Błąd: " . htmlspecialchars($e->getMessage());
}