<?php
$conn = new mysqli('localhost', 'root', '', 'schola');
if ($conn->connect_error) {
    die('Błąd połączenia: ' . $conn->connect_error);
} else {
    echo 'Połączono z bazą danych!';
}
?>
