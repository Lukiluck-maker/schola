<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// add_song_ajax.php
header('Content-Type: application/json; charset=utf-8');

// Prosta walidacja
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Metoda niedozwolona']);
    exit;
}

try {
    $db = new PDO('sqlite:' . __DIR__ . '/db.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $tytul = trim($_POST['tytul'] ?? '');
    if ($tytul === '') throw new Exception('Brak tytułu');

    $stmt = $db->prepare("INSERT INTO piesni (tytul, hymn_number, okres, rodzaj, status, notes, audio, pdf, tekst) VALUES (:tytul,:hymn_number, :okres,:rodzaj,:status,:notes,:audio,:pdf,:tekst)");
    $stmt->execute([
        ':tytul' => $title,
        ':hymn_number' => $_POST['hymn_number'] ?? null,
        ':okres' => $_POST['okres'] ?? null,
        ':rodzaj' => $_POST['rodzaj'] ?? null,
        ':status' => $_POST['status'] ?? null,
        ':notatki' => $_POST['notatki'] ?? null,
        ':audio' => $_POST['audio'] ?? null,
        ':pdf' => $_POST['pdf'] ?? null,
        ':tekst' => $_POST['tekst'] ?? null,
    ]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}