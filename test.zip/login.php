<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';

    // Hasło do zmiany na Twoje bezpieczne
    $correct_password = 'schola123';

    if ($password === $correct_password) {
        $_SESSION['logged_in'] = true;
        header('Location: admin.php');
        exit;
    } else {
        $err = 'Niepoprawne hasło.';
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <title>Logowanie – Schola</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 400px; margin: 40px auto; padding: 10px; }
    label, input, button { display: block; width: 100%; margin-bottom: 10px; font-size: 1.1em; }
    input { padding: 8px; }
    button { background: #2a7ae2; color: white; border: none; cursor: pointer; padding: 10px; border-radius: 5px; }
    button:hover { background: #1860c0; }
    .error { color: #c0392b; margin-bottom: 15px; }
  </style>
</head>
<body>

  <h1>Logowanie – Schola</h1>
  <?php if ($err): ?>
    <div class="error"><?= htmlspecialchars($err) ?></div>
  <?php endif; ?>

  <form method="post" action="login.php" autocomplete="off">
    <label for="password">Hasło:</label>
    <input type="password" id="password" name="password" required autofocus />
    <button type="submit">Zaloguj się</button>
  </form>

</body>
</html>