<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

// Dane do połączenia - dostosuj do siebie!
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'schola';

// Połączenie z bazą
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Błąd połączenia z bazą: ' . $conn->connect_error]);
    exit;
}

// Zapytanie
$sql = "SELECT id, tytul, hymn_number, okres, rodzaj, status, notes, audio, pdf, tekst FROM piesni ORDER BY tytul ASC";
$result = $conn->query($sql);

if (!$result) {
    http_response_code(500);
    echo json_encode(['error' => 'Błąd zapytania: ' . $conn->error]);
    exit;
}

$piesni = [];
while ($row = $result->fetch_assoc()) {
    $piesni[] = $row;
}

echo json_encode($piesni);

$conn->close();