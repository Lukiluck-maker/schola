<?php
try {
    $db = new PDO('sqlite:' . __DIR__ . '/db.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Sprawdź, czy istnieje tabela piesni
    $result = $db->query("SELECT name FROM sqlite_master WHERE type='table' AND name='piesni'");
    $tableExists = $result->fetch();

    if ($tableExists) {
        echo "Tabela 'piesni' istnieje w bazie danych.";
    } else {
        echo "Tabela 'piesni' NIE istnieje w bazie danych.";
    }
} catch (Exception $e) {
    echo "Błąd: " . $e->getMessage();
}
?>
